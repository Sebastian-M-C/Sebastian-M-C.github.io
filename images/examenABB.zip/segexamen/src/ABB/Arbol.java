
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ABB;

import ABB.nodo;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MARCELO
 */
public class Arbol {

    nodo raiz;

    public Arbol() {
        this.raiz = null;
    }

    public void insertar(int x) {
        this.raiz = insertar(this.raiz, x);
    }

    private nodo insertar(nodo p, int x) {
        if (p == null) {
            return new nodo(x);
        }
        if (x < p.elem) {
            p.izq = insertar(p.izq, x);
        } else {
            p.der = insertar(p.der, x);
        }
        return p;
    }
// PRIMER METODO

    public void inOrden() {
        inOrden(this.raiz);
        System.out.println("");
    }

    private void inOrden(nodo p) {
        if (p != null) {
            inOrden(p.izq);
            System.out.print(p.elem + ", ");
            inOrden(p.der);
        }
    }
// SEGUNDO METODO

    public int suma() {
        return suma(this.raiz);
    }

    private int suma(nodo p) {
        if (p == null) {
            return 0;
        }
        return suma(p.izq) + suma(p.der) + p.elem;
    }

    // TERCERO  METODO
    public int cantNodo() {
        return cantNodo(this.raiz);
    }

    private int cantNodo(nodo p) {
        if (p == null) {
            return 0;
        }
        return cantNodo(p.izq) + cantNodo(p.der) + 1;
    }
    // CUARTO METODO

    public int mayor() {
        if (raiz == null) {
            System.out.println("el arbol esta vacio");
        }
        return mayor(raiz);
    }

    private int mayor(nodo p) {
        if (p.der == null) {
            return p.elem;
        }
        return mayor(p.der);
    }
    // QUINTO METODO

    public int altura() {
        return altura(raiz);
    }

    private int altura(nodo p) {
        if (p == null) {
            return 0;
        }
        int altIzq = altura(p.izq);
        int altDer = altura(p.der);
        return 1 + Math.max(altIzq, altDer);

    }

    // SEXTO METODO
    public boolean existe(int num) {
        return existe(this.raiz, num);
    }

    private boolean existe(nodo p, int num) {
        if (p == null) {
            return false;
        }
        if (p.elem == num) {
            return true;
        }
        return existe(p.izq, num) || existe(p.der, num);
    }

    // 5 METODOS DE ELIMINAR ARBOL
    public void eliminar(int num) {
        this.raiz = eliminar(this.raiz, num);
    }

    public nodo eliminar(nodo p, int x) {
        if (p == null) {
            return null;
        }
        if (x == p.elem) {
            return eliminarNodo(p);
        }
        if (x < p.elem) {
            p.izq = eliminar(p.izq, x);
        } else {
            p.der = eliminar(p.der, x);
        }
        return p;
    }

    public nodo eliminarNodo(nodo p) {
        if (p.izq == null && p.der == null) {
            return null;
        }
        if (p.izq != null && p.der == null) {
            return p.izq;
        }
        if (p.izq == null && p.der != null) {
            return p.der;
        }
        int y = inmediatoSup(p.der);
        p.elem = y;
        p.der = eliminar(p.der, y);
        return p;
    }

    public int inmediatoSup(nodo p) {
        if (p.izq == null) {
            return p.elem;
        } else {
            return inmediatoSup(p.izq);
        }
    }
//Primer Metodo

    public void eliminarPar() {
        eliminarPar(this.raiz);
    }

    private void eliminarPar(nodo p) {
        if (p != null) {
            if (p.elem % 2 == 0) {
                eliminar(p.elem);
            }
            eliminarPar(p.izq);
            eliminarPar(p.der);
        }
    }
//SEGUNDO METODO

    public void eliminarMenor() {
        raiz = eliminarMenor(raiz);
    }

    private nodo eliminarMenor(nodo p) {
        if (p == null) {
            return null;
        }
        if (p.izq == null) {
            return p.der;
        }
        p.izq = eliminarMenor(p.izq);
        return p;
    }

    //TERCER METODO
    public void eliminarLadoDer() {
        raiz = eliminarLadoDer(raiz);
    }

    private nodo eliminarLadoDer(nodo p) {
        if (p == null) {
            return null;
        }
        p.izq = eliminarLadoDer(p.izq);
        p.der = null;
        return p;
    }

    //CUARTO  METODO
    public void eliminarRaices() {
        raiz = eliminarRaices(raiz);
    }

    private nodo eliminarRaices(nodo p) {
        if (p == null) {
            return null;
        }
        if (p.izq == null && p.der == null) {
            return null;
        }
        p.izq = eliminarRaices(p.izq);
        p.der = eliminarRaices(p.der);
        return p;
    }

//QUINTO METODO

    public void eliminarPrimos() {
        eliminarPrimos(this.raiz);
    }

    private void eliminarPrimos(nodo p) {
        if (p != null) {
            if (p.elem == 1 || p.elem == 2 || p.elem == 3 || p.elem == 5 || p.elem == 7) {
                eliminar(p.elem);
            }
            eliminarPrimos(p.izq);
            eliminarPrimos(p.der);
        }
    }

     public void eliminarNodosConUnaHoja()
    {
        raiz = eliminarNodosConUnaHoja(raiz);
    }
    private nodo eliminarNodosConUnaHoja(nodo p)
    {
        if (p == null)
            return null;
        p.izq = eliminarNodosConUnaHoja(p.izq);
        p.der = eliminarNodosConUnaHoja(p.der);
        if (p.izq == null && p.der != null) {
            return p.der;
        } else
            if (p.izq != null && p.der == null) {
                return p.izq;
            }
        return p;
    }

}

  


