/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ABB;

/**
 *
 * @author MARCELO
 */
public class nodo {
    nodo izq ;
    nodo der;
    int elem;
    public nodo(int num){
        this.izq=this.der=null;
        this.elem=num;
    }

    public nodo(nodo izq, nodo der, int dato) {
        this.izq = izq;
        this.der = der;
        this.elem = dato;
    }
}
