/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listaABB;

/**
 *
 * @author MARCELO
 */
public class Nodo {
    Nodo izq;
    Nodo der;
    String str;
      
    public Nodo (String str){
         izq=der=null;
        this.str=str;
         
    }
}
