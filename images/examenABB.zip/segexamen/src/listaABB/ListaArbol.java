/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listaABB;
import listaABB.Nodo;


/**
 *
 * @author MARCELO
 */
public class ListaArbol {
Nodo raiz;
    public int max;
    public Arboll arbol[];
 

    public ListaArbol(){
        raiz = null;
    }
    public ListaArbol(int max) {
        this.max = max;
        this.arbol = new Arboll[max];

        for (int i = 0; i < max; i++) {
            arbol[i] = new Arboll();
        }
    }
    public void insertar(String str) {
        arbol[str.length()].insertar(str);
    }

    public void asc() {
        for (int i = 0; i < max; i++) {
            arbol[i].Asc();
        }
    }

    //1. Arbol de mayor altura
   
    public Arboll arbolMayorAltura() {

        int maxAltura = -1;
        Arboll arbolMayor = null;

        for (int i = 0; i < max; i++) {
            int alturaActual = arbol[i].altura();
            if (alturaActual > maxAltura) {
                maxAltura = alturaActual;
                arbolMayor = arbol[i];
            }
        }

        return arbolMayor;
    }

    //2. Igual tamaño, cantidad de elementos
    public boolean igualTamaño() {
        int tamañoReferencia = -1;

        for (int i = 0; i < max; i++) {
            if (arbol[i].raiz != null) {
                int tamañoActual = arbol[i].cantidad();
                if (tamañoReferencia == -1) {
                    tamañoReferencia = tamañoActual;
                } else {
                    if (tamañoActual != tamañoReferencia) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    //3. Arbol mas grande cantidad de nodo 
     public Arboll arbolGrande() {
        Arboll arbolMasGrande = arbol[0];

        for (int i = 1; i < max; i++) {
            if (arbol[i].cantidad() > arbolMasGrande.cantidad()) {
                arbolMasGrande = arbol[i];
            }
        }

        return arbolMasGrande;
    }
    
    //4. Arbol que crece secuencialmente
  
      public int frecuenciaNodos() {
    int totalNodos = 0;
    for (int i = 0; i < max; i++) {
        totalNodos += arbol[i].cantidad();
    }
    return totalNodos;

      }

    //5.misma altura
    public boolean mismaAltura() {
        int alturaReferencia = arbol[1].altura();
        System.out.println(1 + " " + alturaReferencia);
        int i = 2;
        while (arbol[i].cantidad() != 0) {
            int alturaActual = arbol[i].altura();
            System.out.println(i + " " + alturaActual);
            if (alturaReferencia != alturaActual) {
                return false;
            }
            i++;
            alturaReferencia = alturaActual;
        }

        return true;
    }

 
  

    public static void main(String[] args) {
        System.out.println("5 metodo LISTA nodo de un Arbol ");
        ListaArbol L1 = new ListaArbol(20);
        L1.insertar("i");
        L1.insertar("aa");
        L1.insertar("a");
        L1.insertar("bb");
        L1.insertar("e");
        L1.insertar("cc");
        L1.insertar("o");
        L1.insertar("dd");
        L1.insertar("u");
        L1.insertar("ee");
        L1.insertar("i");
        L1.insertar("o");
        L1.insertar("ff");

        L1.asc();

        System.out.println("---------------------------------------------------------------");
        System.out.println("1. Arbol de mayor altura ");
        Arboll arbolMasAlto = L1.arbolMayorAltura();

        System.out.println(arbolMasAlto != null ? arbolMasAlto.altura()
                : "No hay árboles disponibles para determinar la altura.");
        arbolMasAlto.altura();
        System.out.println("SERIA ");
        arbolMasAlto.Asc();

        System.out.println("2. devolveme TRUE si es Igual la cantidad de elementos caso contrario FALSE ");
        boolean mismoTamaño = L1.igualTamaño();
        System.out.println(mismoTamaño);
        System.out.println("3. Arbol mas grande cantidad de nodo ");
        Arboll arbolGrande = L1.arbolGrande();
        arbolGrande.cantidad();
        arbolGrande.Asc();

        System.out.println("5. Arbol que tenga MISMA cantidad de nodo TRUE caso contrario FALSE ");
        boolean mismaAltura = L1.mismaAltura();
        System.out.println(mismaAltura);

        System.out.println("4 mostrar las frecuencia arbol");
        int  frecuenciaTotalNodos;
    frecuenciaTotalNodos = L1.frecuenciaNodos();
   
        System.out.println(" es:"+   L1.frecuenciaNodos() );
             
               
    
    }


}
