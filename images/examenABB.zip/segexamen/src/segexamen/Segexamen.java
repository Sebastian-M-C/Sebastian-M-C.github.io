/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segexamen;

import ABB.Arbol;

/**
 *
 * @author MARCELO
 */
public class Segexamen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Arbol A1 = new Arbol();
        A1.insertar(5);
        A1.insertar(3);
        A1.insertar(8);
        A1.insertar(2);
        A1.insertar(6);
        A1.insertar(9);

        System.out.println("1 mostrar inOrden");
        A1.inOrden();/*
        System.out.println("2 mostrar suma");
        System.out.println("     "+A1.suma());
           System.out.println("3 mostrar cantNodo");
        System.out.println("     "+A1.cantNodo());
        System.out.println("5 mostrar mayor dig del Arbol");
        System.out.println("     "+ A1.mayor());
        System.out.println("4 mostrar Altura del arbol");
        System.out.println("     "+A1.altura());
        System.out.println("6 EXISTE EL NUMEERO -6- EN EL ARBOL");
        System.out.println("     "+A1.existe(6));*/
      //  System.out.println(" metodo eliminar nodo de un Arbol ");
        /*A1.eliminar(9);
        A1.inOrden();
        System.out.println("1 metodo eliminar pares");
       A1.eliminarPar();
      A1.inOrden();*/
 /* System.out.println("2 metodo eliminar dig menor ");
        A1.eliminarMenor();
        A1.inOrden();*/
 /* System.out.println("3 metodo eliminar lado Derecho ");
        A1.eliminarLadoDer();
        A1.inOrden();*/

 /*System.out.println("4 metodo eliminar la races finales del arbol ");
        A1.eliminarRaices();
        A1.inOrden();   */
 /* System.out.println("5 metodo eliminar los # primos del arbol ");
        A1.eliminarPrimos();
        A1.inOrden(); */
       /* System.out.println("6 metodo eliminar NODO con 1 HOJA del arbol ");
        A1.eliminarNodosConUnaHoja();
        A1.inOrden();*/
        
     
    }
}
